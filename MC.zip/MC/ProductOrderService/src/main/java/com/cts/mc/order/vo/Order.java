package com.cts.mc.order.vo;

public class Order {

}
