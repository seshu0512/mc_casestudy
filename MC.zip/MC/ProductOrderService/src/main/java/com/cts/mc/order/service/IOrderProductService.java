package com.cts.mc.order.service;

public interface IOrderProductService {
//	public Product addProductToCart(Product product);
//	public List<Product> listCartProducts();

}
