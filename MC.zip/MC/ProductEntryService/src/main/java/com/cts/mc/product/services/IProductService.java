package com.cts.mc.product.services;

import java.util.List;

import com.cts.mc.product.vo.Product;

public interface IProductService {

	public Product addProduct(Product product);
	public Product updateProduct(String productId);
	public Product deleteProduct(String productId);
	public List<Product> getProductById(String productId);
}
