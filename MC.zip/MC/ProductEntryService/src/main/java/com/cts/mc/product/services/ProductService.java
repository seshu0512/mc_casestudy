package com.cts.mc.product.services;

import java.util.Collections;
import java.util.List;

import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.cts.mc.product.vo.Product;

@RestController
@RequestMapping("/product")
public class ProductService  implements IProductService{


	
	@Override
	public Product addProduct(Product product) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Product updateProduct(String productId) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Product deleteProduct(String productId) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	@RequestMapping("/{productId}")
	public List<Product> getProductById(String productId) {
		// TODO Auto-generated method stub
		return  Collections.singletonList(new Product("product001", "TV", 10, 13000.0, 5.0));
	}

}
