package com.cts.mc.product.dao;

import com.cts.mc.product.vo.Product;

public class ProductRepository {
	
	public Product saveProduct(Product product) {
		
		
		return product;
		
	}
	public Product updateProduct(Product product) {
		
		return product;
		
	}

}
