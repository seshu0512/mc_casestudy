package com.cts.mc.user.utils;

import java.io.File;
import java.io.FileInputStream;
import java.io.InputStream;
import java.util.Arrays;
import java.util.List;

import com.cts.mc.user.vo.Product;
import com.cts.mc.user.vo.User;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;

public class JsonRepository {
	ObjectMapper mapper =new ObjectMapper();
	public void addUser() {
	
	try {
	InputStream inputStream= new FileInputStream( new File("D:\\MC\\UserRegistration\\src\\main\\resources\\UserData.json"));
	TypeReference<List<User>> typeReference = new TypeReference<List<User>>() {};
	
	User user1= new User("seshu", "modepalli", "05-02-1986", "seshu.modepalli@gmail.com",Arrays.asList( new Product("product001", "TV", 10, 13000.0, 5.0)));
	mapper.writeValue(new File("D:\\MC\\UserRegistration\\src\\main\\resources\\UserData.json"), user1);
	}
	catch(Exception exception){
	exception.printStackTrace();	
	}
	}
}
