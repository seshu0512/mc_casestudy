package com.cts.mc.user.services;

import java.util.List;

import com.cts.mc.user.vo.User;

public interface IUserRegistrationService {

	public User addUser(User user);
	public List<User> updateUser(String userId);
	public List<User> getUser(String userId);
}
