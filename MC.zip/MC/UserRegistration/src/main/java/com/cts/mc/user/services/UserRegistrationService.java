package com.cts.mc.user.services;

import java.util.Arrays;
import java.util.Collections;
import java.util.List;

import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.RestTemplate;

import com.cts.mc.user.vo.Product;
import com.cts.mc.user.vo.User;

@RestController
@RequestMapping("/user")
public class UserRegistrationService implements IUserRegistrationService {

	@Override
	@RequestMapping("/createUser/{userId}")
	public User addUser(User user) {
		// TODO Auto-generated method stub
		return null;	
	}

	@Override
	@RequestMapping("/updateUser/{userId}")
	public List<User> updateUser(@PathVariable("userId") String userId) {
		// TODO Auto-generated method stub
		return  Collections.singletonList(new User("seshu", "modepalli", "05-02-1986", "seshu.modepalli@gmail.com",Arrays.asList( new Product("product001", "TV", 10, 13000.0, 5.0))));
	}

	@Override
	@RequestMapping("/getUser/{userId}")
	public List<User> getUser(String userId) {
		
		System.out.println("======11111111========");
		
		RestTemplate restTemplate = new RestTemplate();
		
		Product product=restTemplate.getForObject("http://localhost:8082/product/123", Product.class);
		System.out.println("======22222222222========");
		
		System.out.println("Product from ProductEntryService =="+product);
		// TODO Auto-generated method stub
		return  Collections.singletonList( new User("seshu", "modepalli", "05-02-1986", "seshu.modepalli@gmail.com",Arrays.asList( product)));
	}


	

}
